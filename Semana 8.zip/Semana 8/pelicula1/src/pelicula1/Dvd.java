/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pelicula1;

public class Dvd extends Soporte {
    private double capacidadGb;

    public Dvd(double precioBase, double capacidadGb) {
        super(precioBase);
        this.capacidadGb = capacidadGb;
    }

    @Override
    public double calcularPrecio() {
        return precioBase * 1.10; 
    }

   
    public double getCapacidadGb() {
        return capacidadGb;
    }

    public void setCapacidadGb(double capacidadGb) {
        this.capacidadGb = capacidadGb;
    }
}