/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pelicula1;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Ejecutor {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Por favor ingrese 1 para DVD o 2 para VHS:");
        int opcion = entrada.nextInt();
        entrada.nextLine(); 

        System.out.println("Ingrese el título de la película:");
        String titulo = entrada.nextLine();
        System.out.println("Ingrese el autor de la película:");
        String autor = entrada.nextLine();
        System.out.println("Ingrese el año de edición:");
        int anoEdicion = entrada.nextInt();
        entrada.nextLine(); 
        System.out.println("Ingrese los idiomas (separados por coma):");
        String idiomasStr = entrada.nextLine();
        List<String> idiomas = Arrays.asList(idiomasStr.split(","));

        System.out.println("Ingrese el precio base del alquiler:");
        double precioBase = entrada.nextDouble();
        entrada.nextLine(); 

        Pelicula1 pelicula;
        if (opcion == 1) {
            System.out.println("Ingrese la capacidad en GB:");
            double capacidadGb = entrada.nextDouble();
            Soporte soporte = new Dvd(precioBase, capacidadGb);
            pelicula = new Pelicula1(titulo, autor, anoEdicion, idiomas, soporte);
        } else if (opcion == 2) {
            System.out.println("Ingrese el tipo de cinta:");
            String tipoCinta = entrada.nextLine();
            Soporte soporte = new Vhs(precioBase, tipoCinta);
            pelicula = new Pelicula1(titulo, autor, anoEdicion, idiomas, soporte);
        } else {
            System.out.println("Error, opción no válida.");
            return;
        }

        System.out.printf("El precio de alquiler de la película es: %.2f\n", pelicula.calcularPrecio());
    }
}