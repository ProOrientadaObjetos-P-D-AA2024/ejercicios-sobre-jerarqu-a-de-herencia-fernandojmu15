/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pelicula1;

import java.util.List;

public class Pelicula1 {
    private String titulo;
    private String autor;
    private int anoEdicion;
    private List<String> idiomas;
    private Soporte soporte;

    public Pelicula1(String titulo, String autor, int anoEdicion, List<String> idiomas, Soporte soporte) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoEdicion = anoEdicion;
        this.idiomas = idiomas;
        this.soporte = soporte;
    }

    public double calcularPrecio() {
        return soporte.calcularPrecio();
    }

    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnoEdicion() {
        return anoEdicion;
    }

    public void setAnoEdicion(int anoEdicion) {
        this.anoEdicion = anoEdicion;
    }

    public List<String> getIdiomas() {
        return idiomas;
    }

    public void setIdiomas(List<String> idiomas) {
        this.idiomas = idiomas;
    }

    public Soporte getSoporte() {
        return soporte;
    }

    public void setSoporte(Soporte soporte) {
        this.soporte = soporte;
    }
}