/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pelicula1;

public class Vhs extends Soporte {
    private String tipoCinta;

    public Vhs(double precioBase, String tipoCinta) {
        super(precioBase);
        this.tipoCinta = tipoCinta;
    }

    @Override
    public double calcularPrecio() {
        return precioBase; 
    }

    public String getTipoCinta() {
        return tipoCinta;
    }

    public void setTipoCinta(String tipoCinta) {
        this.tipoCinta = tipoCinta;
    }
}