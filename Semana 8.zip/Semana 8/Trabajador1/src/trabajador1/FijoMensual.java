/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajador1;
public class FijoMensual extends Trabajador1 {
    private double sueldoMensual;

    public FijoMensual(String nombre, String apellidos, String direccion, String dni, double sueldoMensual) {
        super(nombre, apellidos, direccion, dni);
        this.sueldoMensual = sueldoMensual;
    }

    @Override
    public double calcularSueldo() {
        return sueldoMensual;
    }

    // Getters y setters
    public double getSueldoMensual() {
        return sueldoMensual;
    }

    public void setSueldoMensual(double sueldoMensual) {
        this.sueldoMensual = sueldoMensual;
    }
}