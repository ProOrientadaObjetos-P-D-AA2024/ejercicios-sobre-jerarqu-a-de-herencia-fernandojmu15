    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajador1;
public class Comisionista extends Trabajador1 {
    private double porcentajeComision;
    private double ventasRealizadas;

    public Comisionista(String nombre, String apellidos, String direccion, String dni, double porcentajeComision) {
        super(nombre, apellidos, direccion, dni);
        this.porcentajeComision = porcentajeComision;
        this.ventasRealizadas = 0; 
    }

    public void registrarVentas(double ventas) {
        this.ventasRealizadas += ventas;
    }

    @Override
    public double calcularSueldo() {
        return ventasRealizadas * (porcentajeComision / 100);
    }

    
    public double getPorcentajeComision() {
        return porcentajeComision;
    }

    public void setPorcentajeComision(double porcentajeComision) {
        this.porcentajeComision = porcentajeComision;
    }

    public double getVentasRealizadas() {
        return ventasRealizadas;
    }

    public void setVentasRealizadas(double ventasRealizadas) {
        this.ventasRealizadas = ventasRealizadas;
    }
}