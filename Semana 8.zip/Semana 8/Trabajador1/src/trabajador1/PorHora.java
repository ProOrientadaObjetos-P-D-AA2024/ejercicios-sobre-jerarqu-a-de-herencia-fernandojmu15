/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajador1;

public class PorHora extends Trabajador1 {
    private double precioHora;
    private int horasTrabajadas;

    public PorHora(String nombre, String apellidos, String direccion, String dni, double precioHora) {
        super(nombre, apellidos, direccion, dni);
        this.precioHora = precioHora;
        this.horasTrabajadas = 0; // Inicializamos las horas trabajadas en 0
    }

    public void registrarHoras(int horas) {
        this.horasTrabajadas += horas;
    }

    @Override
    public double calcularSueldo() {
        double sueldo = 0;
        if (horasTrabajadas <= 40) {
            sueldo = horasTrabajadas * precioHora;
        } else {
            sueldo = (40 * precioHora) + ((horasTrabajadas - 40) * precioHora * 1.5); // 1.5 es el factor para horas extras
        }
        return sueldo;
    }

    public double getPrecioHora() {
        return precioHora;
    }

    public void setPrecioHora(double precioHora) {
        this.precioHora = precioHora;
    }

    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }
}