/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajador1;


public class Ejecutor {
public static void main(String[] args) {
     
        Trabajador1 fijo = new FijoMensual("Isaias", "Gomez", "Calle 1473", "12458778A", 5630);
        Trabajador1 comisionista = new Comisionista("Rous", "Guallo", "Calle 12", "548484848B", 545);
        Trabajador1 porHoras = new PorHora("Manuel", "Reulio", "Calle 9", "551584432C", 54510);
        Trabajador1 jefe = new Jefe("lupe", "Martínez", "Calle 10574", "11255420D", 54678);


        ((Comisionista) comisionista).setVentasRealizadas(10000);

    
        ((PorHora) porHoras).setHorasTrabajadas(50);

   
        fijo.imprimirNomina();
        comisionista.imprimirNomina();
        porHoras.imprimirNomina();
        jefe.imprimirNomina();
    }
}