/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mensajeria;
public class SMS extends Mensaje {
    private String contenido;

    public SMS(String remitente, String destinatario, String nombreRemitente, String nombreDestinatario, String contenido) {
        super(remitente, destinatario, nombreRemitente, nombreDestinatario);
        this.contenido = contenido;
    }

    @Override
    public void enviarMensaje() {
        System.out.println("Enviando SMS: " + contenido + " de " + remitente + " a " + destinatario);
    }

    @Override
    public void visualizarMensaje() {
        System.out.println("SMS de " + nombreRemitente + " (" + remitente + ") a " + nombreDestinatario + " (" + destinatario + "): " + contenido);
    }

 
    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
}