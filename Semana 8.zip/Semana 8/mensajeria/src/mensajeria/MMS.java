/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mensajeria;


public class MMS extends Mensaje {
    private String nombreArchivoImagen;

    public MMS(String remitente, String destinatario, String nombreRemitente, String nombreDestinatario, String nombreArchivoImagen) {
        super(remitente, destinatario, nombreRemitente, nombreDestinatario);
        this.nombreArchivoImagen = nombreArchivoImagen;
    }

    @Override
    public void enviarMensaje() {
        System.out.println("Enviando MMS: " + nombreArchivoImagen + " de " + remitente + " a " + destinatario);
    }

    @Override
    public void visualizarMensaje() {
        System.out.println("MMS de " + nombreRemitente + " (" + remitente + ") a " + nombreDestinatario + " (" + destinatario + "): " + nombreArchivoImagen);
    }


    public String getNombreArchivoImagen() {
        return nombreArchivoImagen;
    }

    public void setNombreArchivoImagen(String nombreArchivoImagen) {
        this.nombreArchivoImagen = nombreArchivoImagen;
    }
}