/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mensajeria;

import java.util.Scanner;

public class Ejecutor {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Ingrese 1 para enviar SMS o 2 para enviar MMS:");
        int opcion = entrada.nextInt();
        entrada.nextLine(); // Consume newline

        System.out.println("Ingrese el número del remitente:");
        String remitente = entrada.nextLine();
        System.out.println("Ingrese el número del destinatario:");
        String destinatario = entrada.nextLine();
        System.out.println("Ingrese el nombre del remitente (opcional):");
        String nombreRemitente = entrada.nextLine();
        System.out.println("Ingrese el nombre del destinatario (opcional):");
        String nombreDestinatario = entrada.nextLine();

        Mensaje mensaje;
        if (opcion == 1) {
            System.out.println("Ingrese el contenido del SMS:");
            String contenido = entrada.nextLine();
            mensaje = new SMS(remitente, destinatario, nombreRemitente, nombreDestinatario, contenido);
        } else if (opcion == 2) {
            System.out.println("Ingrese el nombre del archivo de imagen del MMS:");
            String nombreArchivoImagen = entrada.nextLine();
            mensaje = new MMS(remitente, destinatario, nombreRemitente, nombreDestinatario, nombreArchivoImagen);
        } else {
            System.out.println("Error, opción no válida.");
            return;
        }

        mensaje.enviarMensaje();
        mensaje.visualizarMensaje();
    }
}